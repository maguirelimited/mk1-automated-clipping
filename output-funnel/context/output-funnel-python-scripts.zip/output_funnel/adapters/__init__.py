"""Platform publisher adapters."""
